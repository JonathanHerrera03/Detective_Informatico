# Detective Informático · Proyecto local para XAMPP

Esta entrega contiene la aplicación completa para ejecutarse con Apache, PHP y MySQL/MariaDB. phpMyAdmin se utiliza para importar, consultar y exportar la base de datos. El acceso es con correo y contraseña propios.

Incluye seis módulos, 31 lecciones, seis actividades, seis casos, 21 preguntas iniciales, evaluación final, resultados, puntos, seguimiento, constancia imprimible y paneles de estudiante, docente y administrador.

## 1. Colocar el proyecto

Descomprime el ZIP. Copia la carpeta **detective-informatico** dentro de:

`C:\xampp\htdocs\`

La estructura debe quedar así:

```text
C:\xampp\htdocs\detective-informatico\index.php
C:\xampp\htdocs\detective-informatico\instalar.php
C:\xampp\htdocs\detective-informatico\api\academia.php
C:\xampp\htdocs\detective-informatico\database\detective_informatico.sql
```

Si ya existe una carpeta con ese nombre, conserva una copia antes de reemplazarla. Abre el panel de XAMPP e inicia **Apache** y **MySQL**.

## 2. Importar la base de datos

1. Abre `http://localhost/phpmyadmin/`.
2. En la pantalla del servidor, selecciona **Importar**.
3. Selecciona `database/detective_informatico.sql` de esta entrega.
4. Confirma la importación. El archivo crea la base **detective_informatico**, sus nueve tablas y los contenidos educativos.

No necesitas crear las tablas manualmente. El SQL usa UTF-8 y es compatible con MySQL y con MariaDB incluido en XAMPP. No contiene instrucciones para eliminar bases o tablas existentes. Para una instalación inicial, utiliza una base nueva con el nombre indicado.

## 3. Conservar los datos de la plataforma anterior (opcional)

La entrega también incluye `database/datos_existentes.sql`, exportado de la versión alojada. Incluye los perfiles, resultados y asignaciones que existían al preparar la entrega. El resumen exacto está en `docs/resumen-exportacion.json`.

Si deseas conservarlos, importa ese archivo **después** del SQL principal y **antes** de completar `instalar.php`. La instalación reconocerá el perfil administrador importado y le asignará la contraseña local que elijas, conservando su identificador y resultados.

Las contraseñas de ChatGPT no forman parte de la exportación. Si se importan otros perfiles, el administrador deberá asignarles una contraseña local desde **Usuarios → Editar usuario**. El archivo de exportación contiene datos de los perfiles; consérvalo como una copia local.

## 4. Configurar la conexión

Abre `config/config.php`. Los valores predeterminados corresponden a una instalación local habitual de XAMPP:

```php
'host' => '127.0.0.1',
'port' => '3306',
'database' => 'detective_informatico',
'username' => 'root',
'password' => '',
```

Si tu usuario MySQL tiene contraseña o utiliza otro puerto, cambia esos valores. Esta es la contraseña de MySQL; las cuentas de estudiantes y docentes se crean desde la aplicación.

## 5. Crear el administrador

Abre en el computador que ejecuta XAMPP:

**`http://localhost/detective-informatico/instalar.php`**

Introduce tu nombre, correo y una contraseña de al menos 10 caracteres. No existe una contraseña administradora predeterminada. Cuando se completa este paso, la creación inicial de administrador queda bloqueada automáticamente.

La instalación inicial solo se permite desde `localhost`. Si importaste el perfil anterior, revisa el nombre y correo que aparecen y establece su nueva contraseña.

## 6. Usar la plataforma

Abre **`http://localhost/detective-informatico/`**.

- Los nuevos usuarios utilizan **Registrarme** y eligen **Estudiante** o **Profesor**. La cuenta de profesor utiliza el rol interno `docente`.
- Solo un administrador puede crear otras cuentas administradoras desde **Usuarios → Crear administrador**. El registro público no permite elegir ni enviar el rol administrador.
- El administrador cambia roles y estados desde **Usuarios**. Puede editar nombres, correos y contraseñas de todos los perfiles, incluidos otros administradores y su propia cuenta.
- Debe quedar al menos un administrador activo. El sistema impide desactivar o degradar al último.
- El docente consulta estudiantes, asigna módulos y gestiona preguntas y casos.
- La evaluación final se desbloquea al aprobar las cinco evaluaciones anteriores con 70% o más.
- Los resultados y asignaciones se guardan en MySQL. Los puntos del perfil toman el mejor resultado por reto.
- Antes de iniciar sesión se muestra una portada de presentación con información de la plataforma, su metodología y los accesos de registro e inicio de sesión.
- Los módulos, actividades, casos, evaluaciones y resultados requieren una sesión. Al cerrarla se limpia la vista privada y se regresa a la portada pública, también al recargar.
- El acceso anónimo al modo práctica se retiró; los contenidos activos se cargan desde MySQL después de iniciar sesión.
- Desde **Perfil** puedes cambiar tu contraseña. Si un estudiante la olvida, un administrador puede restablecerla desde **Usuarios**.

No se envían correos automáticos. El correo sirve como identificador de acceso y no se verifica mediante mensajes.

## 7. Acceder desde otro computador

Los dos equipos deben estar en la misma red local. En el computador servidor:

1. Mantén Apache y MySQL activos.
2. Consulta su dirección IPv4 con `ipconfig`.
3. En el otro equipo abre `http://IP_DEL_SERVIDOR/detective-informatico/`.

Por ejemplo, si la IP del servidor fuera `192.168.1.20`, el enlace sería `http://192.168.1.20/detective-informatico/`. Es un ejemplo; utiliza la IP real de tu equipo.

En otro computador, `localhost` apunta a ese computador, por eso se sustituye por la IP del servidor. Si Windows bloquea Apache, autoriza su acceso en la red privada que estés utilizando. El navegador cliente se comunica con Apache; no necesita acceso directo al puerto de MySQL ni a phpMyAdmin.

Si Apache usa un puerto diferente al 80, inclúyelo: `http://IP_DEL_SERVIDOR:PUERTO/detective-informatico/`.

## Requisitos y funcionamiento sin Internet

PHP 8.0 o superior, extensiones `pdo_mysql`, `mbstring`, `json` y `session`, MySQL/MariaDB y un navegador moderno. Los recursos visuales y JavaScript ya están compilados y se incluyen en `assets/`. La aplicación funciona sin conexión a Internet una vez instalada.

No necesitas Node.js, npm, Composer, ChatGPT ni un dominio comprado para ejecutar esta versión local. Las instrucciones de esta entrega están orientadas al computador local o una red de laboratorio.

## Archivos principales

| Ruta | Función |
|---|---|
| `index.php` | Entrada a la plataforma |
| `instalar.php` | Alta o activación inicial del administrador |
| `config/config.php` | Conexión MySQL y duración de sesión |
| `api/bootstrap.php` | Conexión PDO, sesiones, validación y funciones comunes |
| `api/academia.php` | Registro, acceso, permisos, corrección y gestión |
| `database/detective_informatico.sql` | Esquema y contenidos educativos |
| `database/datos_existentes.sql` | Importación opcional de registros anteriores |
| `frontend/src/academy.tsx` | Código fuente editable de la interfaz |
| `frontend/src/content.ts` | Referencia del contenido inicial y tipos de la interfaz |
| `frontend/src/*.css` | Estilos de la plataforma |
| `assets/app.js` y `assets/app.css` | Interfaz compilada para uso inmediato |
| `tests/` | Herramientas de importación y comprobaciones para desarrollo |

## Editar y recompilar la interfaz (solo desarrollo)

Las pantallas usan React compilado a JavaScript. Para cambiar contenido educativo, utiliza los paneles del administrador y docente; esos cambios se guardan directamente en MySQL.

Si modificas los archivos de `frontend/src/`, instala Node.js, abre una terminal en `frontend/`, ejecuta `npm install` y después `npm run build`. Esto actualiza los archivos de `assets/`. La primera instalación de las herramientas de desarrollo sí requiere Internet. Los cambios en PHP se aplican directamente y no requieren recompilar.

VS Code ya incluye soporte de React y TypeScript. Ejecuta `npm install` dentro de `frontend/` para que encuentre React, sus tipos y las demás dependencias. La configuración del editor está en `frontend/tsconfig.json`. Si los subrayados continúan tras la instalación, abre la paleta con Ctrl+Shift+P y ejecuta **TypeScript: Restart TS Server**. Para comprobar los tipos utiliza `npx tsc --noEmit`. Las extensiones adicionales son opcionales.

## Copias de seguridad

En phpMyAdmin selecciona **detective_informatico → Exportar → SQL** para guardar usuarios, contenidos y resultados actuales. La exportación JSON de la aplicación sirve como copia legible de los registros visibles, no como restaurador automático.

Los SQL incluidos en esta entrega reflejan el momento de exportación. Los nuevos resultados locales se guardarán en tu MySQL y deben respaldarse desde ahí.

## Problemas habituales

- **No carga la página:** comprueba que Apache esté activo, la carpeta esté dentro de `htdocs` y estés usando una dirección `http://`, no abriendo el archivo con doble clic.
- **Error de base de datos:** inicia MySQL, importa el SQL y verifica nombre, usuario, contraseña y puerto en `config/config.php`.
- **Página 404:** revisa que no haya una carpeta duplicada, como `detective-informatico/detective-informatico/`.
- **Error 403 al abrir un SQL o código fuente en el navegador:** es la protección de Apache. Elige el SQL desde el cuadro de importación de phpMyAdmin o abre los archivos con un editor local.
- **La sesión cambió:** recarga la página y vuelve a intentar la operación.
- **Un perfil importado no puede entrar:** asígnale una contraseña desde Usuarios; las claves de ChatGPT no se trasladan.
- **Demasiados intentos:** espera el plazo indicado antes de volver a iniciar sesión.

## Comprobaciones y seguridad implementadas

Contraseñas protegidas mediante `password_hash`/`password_verify`, consultas preparadas PDO, sesiones con cookies HttpOnly, token CSRF, limitación de intentos de acceso y autorización en el servidor. La aplicación nunca devuelve hashes de contraseñas al navegador. Cambiar una contraseña invalida las demás sesiones de ese usuario. La edición de administradores utiliza una transacción y bloqueo para conservar un administrador activo.

Las instrucciones para pruebas de desarrollo están en `tests/LEEME.md`. El resultado de la revisión realizada al preparar la entrega está en `docs/VERIFICACION.md`.
