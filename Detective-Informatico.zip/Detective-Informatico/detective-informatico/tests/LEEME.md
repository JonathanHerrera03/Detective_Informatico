# Herramientas de desarrollo

La instalación normal está explicada en `../LEEME.md` y se realiza con phpMyAdmin. No necesitas ejecutar estas pruebas para utilizar la aplicación.

`importar_cli.php` permite importar el SQL principal con PHP CLI usando la conexión de `config/config.php`. También acepta el argumento `datos_existentes.sql` para esa importación opcional. Solo se ejecuta desde terminal.

`comprobar.mjs` ejecuta pruebas contra Apache y MySQL reales. Requiere Node.js >=22 y una base de prueba vacía con los contenidos importados. **Crea cuentas y modifica registros: no lo ejecutes sobre datos reales.** La URL debe apuntar a localhost y se requiere la variable `DETECTIVE_QA_ALLOW_SETUP=1`. La URL de pruebas se configura con `DETECTIVE_QA_URL`, con barra final y carpeta del proyecto; el valor predeterminado es `http://127.0.0.1:8089/detective-informatico/`.

El puerto 8089 corresponde al entorno aislado utilizado para verificar la entrega. En tu equipo debes preparar una instancia de prueba y ajustar la URL si deseas repetir los casos. El proyecto normal utiliza los puertos configurados en tu XAMPP.

Las variables `DETECTIVE_DB_HOST`, `DETECTIVE_DB_PORT`, `DETECTIVE_DB_NAME`, `DETECTIVE_DB_USER` y `DETECTIVE_DB_PASSWORD` permiten conectar las herramientas a una instancia aislada sin editar la configuración normal. La importación SQL principal crea y selecciona la base `detective_informatico`; si necesitas otro nombre para pruebas, adapta tanto las instrucciones CREATE/USE del SQL como la configuración.

Las credenciales que aparecen dentro del script son únicamente para sus cuentas ficticias de prueba. La entrega no crea esas cuentas en la base de datos inicial.
