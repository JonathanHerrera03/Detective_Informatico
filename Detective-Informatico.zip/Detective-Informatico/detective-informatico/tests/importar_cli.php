<?php
// Alternativa para desarrolladores. La instalación normal se hace en phpMyAdmin.
if (PHP_SAPI!=='cli') { http_response_code(403); exit; }
$config=require __DIR__.'/../config/config.php';
$file=$argv[1]??'detective_informatico.sql';
if (!in_array($file,['detective_informatico.sql','datos_existentes.sql'],true)) { fwrite(STDERR,"Archivo no permitido.\n");exit(1); }
$pdo=new PDO('mysql:host='.$config['host'].';port='.$config['port'].';charset=utf8mb4',$config['username'],$config['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$pdo->exec(file_get_contents(__DIR__.'/../database/'.$file));
echo "Importación completada: $file\n";
