# Estructura de la base de datos

Nombre: `detective_informatico`. Motor: InnoDB. Codificación: utf8mb4. Gestor: MySQL o MariaDB; administración mediante phpMyAdmin.

| Tabla | Contenido |
|---|---|
| `usuarios` | Perfil, correo único, hash de contraseña, rol, estado y versión de sesión |
| `modulos` | Los seis módulos y sus lecciones educativas |
| `preguntas` | Preguntas, cuatro opciones, respuesta correcta y explicación |
| `casos` | Escenarios, pistas, soluciones y retroalimentación |
| `actividades` | Elementos para relacionar u ordenar y solución de cada reto |
| `resultados` | Cada intento de actividad, caso o evaluación, fecha y puntuación |
| `asignaciones` | Módulos asignados por el docente a un estudiante |
| `configuracion` | Nombre del laboratorio y registro usado para bloquear la gestión concurrente de administradores |
| `intentos_acceso` | Contadores temporales de registro y acceso; las claves son hashes, no direcciones IP en texto |

Las listas de opciones, pistas, elementos y lecciones se guardan como JSON en columnas LONGTEXT para mantener compatibilidad con MySQL y MariaDB de XAMPP. PHP valida su contenido y lo interpreta al responder a la interfaz.

```mermaid
erDiagram
    usuarios ||--o{ resultados : realiza
    usuarios ||--o{ asignaciones : recibe
    usuarios o|--o{ preguntas : crea
    usuarios o|--o{ casos : crea
    modulos ||--o{ resultados : registra
    modulos ||--o{ preguntas : contiene
    modulos ||--o{ casos : contiene
    modulos ||--|| actividades : incluye
    modulos ||--o{ asignaciones : asignado
```

Cada intento guarda su denominador, puntuación y fecha originales. Eliminar una pregunta o caso no elimina resultados previos. Eliminar un usuario elimina sus resultados y asignaciones recibidas; los contenidos creados por él permanecen con autor vacío.

`contrasena_hash` es NULL únicamente en perfiles importados que todavía no tienen clave local. No pueden iniciar sesión hasta que se configure una contraseña. No se importan credenciales de servicios externos.

Los SQL no contienen DROP DATABASE ni DROP TABLE. Las inserciones iniciales utilizan INSERT IGNORE para evitar reemplazar registros que ya existan con el mismo identificador. Para restaurar una copia completa posterior, utiliza la exportación realizada desde phpMyAdmin y revisa su destino antes de importarla.
