# Verificación de la entrega local

Revisión realizada el 18 de octubre de 2026, hora de Panamá.

## Entorno utilizado

- Windows con los ejecutables instalados de XAMPP.
- Apache 2.4.58, PHP 8.0.30 y MariaDB 10.4.32.
- Instancias de prueba independientes en los puertos 8089 y 3307, con configuración y datos separados de las bases habituales del equipo.
- Navegador integrado para comprobar la interfaz, el inicio de sesión y la edición de la propia cuenta administradora.

## Resultado: correcto

Se comprobó la importación del esquema y los contenidos: nueve tablas, seis módulos, 31 lecciones, 21 preguntas, seis casos y seis actividades.

Las comprobaciones de integración utilizaron solicitudes HTTP reales a Apache y persistencia en MariaDB. Verificaron:

- Creación inicial del administrador y bloqueo de una segunda instalación.
- Registro de estudiantes, acceso, cierre de sesión y rechazo de contraseñas incorrectas.
- Permisos de estudiante, docente y administrador comprobados en el servidor.
- Edición de nombre, correo, rol y estado de la propia cuenta administradora y de otros administradores; protección del último administrador activo.
- Corrección de las seis evaluaciones, seis actividades y seis casos; rechazo de puntuaciones enviadas por el cliente como fuente de calificación.
- Bloqueo de la misión final hasta aprobar las cinco evaluaciones anteriores.
- Conservación de 19 intentos de un estudiante entre distintas sesiones y cambios de contraseña.
- Creación, edición y eliminación de preguntas y casos; edición de módulos y configuración; asignación de módulos.
- Desactivación y reactivación de usuarios.
- Cambio y restablecimiento de contraseñas; invalidación de las otras sesiones de la cuenta afectada.
- Rechazo de solicitudes sin token CSRF mediante HTTP 403.
- Acceso HTTP bloqueado a SQL, configuración, fuentes y pruebas; recursos compilados accesibles.
- Importación opcional del perfil existente sin duplicados y activación con una contraseña local, conservando su identificador.
- Sintaxis de los archivos PHP y compilación de la interfaz.

El archivo `vista-administracion-local.png` muestra el formulario de edición de la propia cuenta en la instancia de prueba. Las personas y claves utilizadas para probar la aplicación no se incluyen como cuentas preconfiguradas en los SQL de entrega.

## Alcance

La ejecución se verificó con MariaDB incluido en XAMPP. No se ejecutó una segunda instancia de MySQL 8. El SQL emplea tablas InnoDB, UTF-8 y tipos compatibles con ambos motores.

El acceso desde otro equipo se documenta en LEEME; requiere que ambos equipos se comuniquen por la red y que Apache tenga acceso permitido. No se realizó una prueba física con un segundo computador. No se cambió la publicación de la plataforma alojada ni la configuración habitual de XAMPP.

Las pruebas de desarrollo están en `tests/`. Deben ejecutarse únicamente en una base de pruebas independiente, como indica su guía.

## Revisión de edición en VS Code

Se añadieron `frontend/tsconfig.json`, TypeScript y los tipos de React y React DOM a las dependencias de desarrollo. El análisis TypeScript 5.9.3 finalizó sin errores con las dependencias declaradas. Para preparar el editor tras extraer la entrega, ejecuta `npm install` en `frontend/`.

## Registro por rol y administración · 20 de octubre de 2026

El registro público permite elegir Estudiante o Profesor (`docente`). El servidor solo acepta esos dos roles; rechaza el rol administrador y los valores no válidos. Se añadió **Usuarios → Crear administrador**, con autorización de administrador en el servidor, validación de correo único y contraseña. Crear otra cuenta no sustituye la sesión actual. La instalación inicial del primer administrador permanece en `instalar.php`.

Las pruebas HTTP en Apache, PHP y MariaDB verificaron ambos registros, rechazo de registro público como administrador, rechazo de creación de administradores desde estudiante, profesor y visitante, creación autorizada, inicio de sesión de la nueva cuenta y protección del último administrador. También pasaron las comprobaciones existentes de resultados, contenidos y contraseñas. La revisión visual confirmó las opciones del registro y el formulario privado. PHP y TypeScript finalizaron sin errores y la interfaz quedó recompilada.

No se requiere migrar ni reimportar el SQL para esta actualización. Las pruebas utilizaron exclusivamente la base aislada del puerto 3307. Las imágenes `registro-estudiante-profesor.png` y `crear-administrador.png` corresponden a esa revisión.

## Portada pública y cierre de sesión · 20 de octubre de 2026

Se creó una página de presentación independiente del panel de aprendizaje. Incluye la identidad de Detective Informático, su metodología, información para estudiantes y profesores, registro e inicio de sesión. Los visitantes no tienen navegación de módulos, casos, evaluaciones, resultados ni selector de demostración. El acceso público al modo práctica se retiró.

El catálogo y las actividades se obtienen del servidor únicamente con una sesión válida. La interfaz dejó de incluir el currículo inicial como datos ejecutables del paquete JavaScript. Al salir se limpian perfil, catálogo, actividades, resultados, asignaciones, filtros y credenciales del formulario. Las respuestas de carga anteriores se descartan y el regreso desde una página conservada por el navegador vuelve a comprobar la sesión.

La prueba HTTP verificó que antes del acceso y después de cerrar sesión el servidor devuelve vacíos el catálogo, las actividades, los resultados, los usuarios y las asignaciones, y rechaza registrar intentos sin sesión. Las comprobaciones existentes de registro por rol, administradores y aprendizaje pasaron. PHP y TypeScript no reportaron errores y la interfaz quedó compilada.

La revisión del navegador confirmó la portada pública, el registro preseleccionado para Profesor, el acceso al panel con una cuenta estudiante de prueba, el regreso a la portada al cerrar sesión y su permanencia tras recargar. La imagen `portada-publica.png` muestra ese estado después del cierre y recarga. Las pruebas se realizaron exclusivamente en la instancia aislada 8089/3307.

Esta actualización cambia archivos de aplicación; no necesita importar de nuevo el SQL y conserva los datos existentes.
