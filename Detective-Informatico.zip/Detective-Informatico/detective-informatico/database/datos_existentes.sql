-- Exportación opcional de perfiles y progreso de la plataforma alojada.
-- Importar DESPUÉS de detective_informatico.sql y ANTES de abrir instalar.php.
-- Las contraseñas de ChatGPT no se exportan: crea la clave del administrador en instalar.php.
-- El administrador asignará una contraseña nueva a los demás perfiles desde Usuarios.
SET NAMES utf8mb4;
USE detective_informatico;
START TRANSACTION;
INSERT IGNORE INTO usuarios (id,nombre,correo,rol,activo,creado) VALUES
('FHcLoKd80yOC7OpmnXvuqmUF0cXNjw3qPZGo7ZMqaoeAOt58C6SePO','Jonathan Herrera','jonathanh3498@gmail.com','administrador',1,'2026-10-18T23:22:39.196Z');
COMMIT;
