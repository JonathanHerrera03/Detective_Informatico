// Reconoce las hojas de estilo que esbuild incorpora a la interfaz.
declare module '*.css' {}
