import {createRoot} from 'react-dom/client';
import Academy from './academy';
import './globals.css';
import './readability.css';
createRoot(document.getElementById('root')!).render(<Academy/>);
